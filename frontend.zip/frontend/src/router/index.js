import { createRouter, createWebHistory } from 'vue-router';

const routes = [
    {
        path: '/login',
        name: 'user.login',
        component: () => import('@/views/Login.vue') 
    },
    {
        path: '/number',
        name: 'number.index',
        component: () => import('@/views/Number/Index.vue') 
    },
    {
        path: '/user',
        name: 'user.layout',
        component: () => import('@/views/User/Layout.vue'),
        children: [
            {
                path: '',
                name: 'user.index',
                component: () => import('@/views/User/Index.vue')
            },
            {
                path: '/show/:user',
                name: 'user.show',
                component: () => import('@/views/User/Show.vue')
            },
        ]
    },
    {
        path: '/phone',
        name: 'phone.layout',
        component: () => import('@/views/Phone/Layout.vue'),
        children: [
            {
                path: '',
                name: 'phone.index',
                component: () => import('@/views/Phone/Index.vue')
            },
            {
                path: 'create/:number?',
                name: 'phone.create',
                component: () => import('@/views/Phone/Create.vue')
            },
            {
                path: 'edit/:phone',
                name: 'phone.edit',
                component: () => import('@/views/Phone/Edit.vue')
            },
            {
                path: 'generate',
                name: 'phone.generate',
                component: () => import('@/views/Phone/Generate.vue')
            },
        ]
    },
    {
        path: '/:pathMatch(.*)*',
        name: '404',
        component: () => import('@/views/Error/404.vue')
    }
];

const router = createRouter({
    history: createWebHistory(),
    routes: routes,
    linkActiveClass: 'active'
});

export default router;