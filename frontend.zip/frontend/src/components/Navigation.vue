<template>
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-3">
        <div class="container">
            <div class="navbar-brand d-flex align-items-center">
                <img src="https://docs.vuejs.id/images/logo.png" width="40">
                <span class="ms-2">
                    P27
                </span>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <router-link class="nav-link" :to="{name: 'number.index'}">Number</router-link>
                    <router-link class="nav-link" :to="{name: 'user.index'}">User</router-link>
                    <router-link class="nav-link" :to="{name: 'phone.index'}">Phone</router-link>
                    <a v-on:click.prevent="logout()" href="#" class="nav-link">Logout</a>
                </div>
            </div>
        </div>
    </nav>
</template>

<script>
    import { useStorage } from 'vue3-storage';

    export default {
        methods: {
            logout: function () {
                const storage = useStorage();
                storage.clearStorageSync();
                this.$router.push({
                    name: 'user.login'
                });
            }
        }
    };
</script>

<style>

</style>
