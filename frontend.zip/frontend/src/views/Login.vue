<template>
    <div class="row justify-content-center align-middle mt-5">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header text-center">
                    <b>LOGIN</b>
                </div>
                <div class="card-body">
                    <div class="d-grid gap-2 mb-3">
                        <button v-on:click="clickGoogleButton()" type="button"  class="btn btn-secondary">
                            <i class="fab fa-google fa-fw"></i> Sign In With Google
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { useStorage } from 'vue3-storage';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { SERVER_API_URL } from './../utils/constant';

export default {
    mounted () {
        const storage = useStorage();
        if (storage.hasKey('user_id')) {
            this.$router.push({
                name: 'user.index'
            });
        }
    },
    data () {
        return {
            login_user: {
                name: '',
                email: '',
                google_id: '',
                avatar: '',
            }
        }
    },
    methods: {
        clickGoogleButton: function () {
            let provider = new GoogleAuthProvider();
            const auth = getAuth();
            signInWithPopup(auth, provider)
            .then((result) => {
                // const credential = GoogleAuthProvider.credentialFromResult(result);
                // const token = credential.accessToken;
                const user = result.user;
                this.login_user.name = user.displayName;
                this.login_user.email = user.email;
                this.login_user.google_id = user.uid;
                this.login_user.avatar = user.photoURL;
                this.saveUser();
            }).catch((error) => {
                // const errorCode = error.code;
                const errorMessage = error.message;
                // const email = error.email;
                // const credential = GoogleAuthProvider.credentialFromError(error);
                this.error = errorMessage;
            });
        },
        saveUser: function () {
            let loader = this.$loading.show();
            let url = SERVER_API_URL + '/user/store';
            let body = this.login_user;
            axios.post(url, body)
            .then(response => {
                let storage = useStorage();
                storage.setStorage({
                    key: 'user_id',
                    data: response.data.user.id,
                    success: () => {
                        loader.hide();
                        this.$router.push({
                            name: 'user.index'
                        });
                    }
                });
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        }
    }
}
</script>

<style>

</style>