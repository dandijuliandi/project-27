<template>
    <Navigation></Navigation>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-6">
                <button v-on:click="changeSoundStatus()" class="btn btn-primary">
                    <i v-if="sound_status == true" class="fas fa-fw fa-bell"></i>
                    <i v-else class="fas fa-fw fa-bell-slash"></i>
                    Notification Sound
                </button>
            </div>
            <div class="col-md-6">

            </div>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">ODD</div>
                    <div class="card-body text-center">
                        <h1>{{ odd }}</h1>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header text-center">EVEN</div>
                    <div class="card-body text-center">
                        <h1>{{ even }}</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { useStorage } from 'vue3-storage';
import navigation from './../../components/Navigation.vue';
import { getDatabase, ref, onValue} from "firebase/database";
import notificaiton_sound from './../../../public/notification_sound.mp3'

export default {
    data () {
        return {
            odd: 0,
            even: 0,
            sound_status: false
        }
    },
    components: {
        Navigation: navigation
    },
    mounted () {
        const storage = useStorage();
        if (!storage.hasKey('user_id')) {
            this.$router.push({
                name: 'user.login'
            });
        } else {
            const db = getDatabase();
            const starCountRef = ref(db, 'number');
            onValue(starCountRef, (snapshot) => {
                const data = snapshot.val();
                this.setData(data);
            });
        }
    },
    methods: {
        setData: function (data) {
            this.odd = data.odd;
            this.even = data.even;
            this.$toast.info('Data has been changed');
            this.playSound(notificaiton_sound);
        },
        playSound: function (sound) {
            if(sound) {
                var audio = new Audio(sound);
                audio.play()
                .catch(() => {
                    this.$toast.warning('Notification sound is disabled');
                });
            }
        },
        changeSoundStatus: function () {
            this.sound_status = true;
            this.$toast.success('Notification sound activated');
        }
    }
}
</script>

<style>

</style>