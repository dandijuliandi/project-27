<template>
    <navigation></navigation>
    <h1>Register.vue</h1>
</template>

<script>
import navigation from './../components/Navigation.vue';

export default {
    components: {
        navigation: navigation
    }
}
</script>

<style>

</style>