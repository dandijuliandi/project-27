<template>
    <Navigation></Navigation>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-3">
                <div class="card">
                    <img :src="user.profile.avatar" class="card-img-top">
                    <div class="card-body text-center">
                        <h5 class="card-title">{{ user.name }}</h5>
                        <p class="card-text">{{ user.email }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { SERVER_API_URL } from './../../utils/constant';
import navigation from './../../components/Navigation.vue';

export default {
    components: {
        Navigation: navigation
    },
    mounted () {
        this.getUser();
    },
    data () {
        return {
            user: {
                name: '',
                email: '',
                profile: {
                    avatar: '',
                    google_id: '',
                },
            },
        }
    },
    methods: {
        getUser: function () {
            let loader = this.$loading.show();
            let url = SERVER_API_URL + '/user/show/' + this.$route.params.user;
            axios.get(url)
            .then(response => {
                this.user = response.data.data;
                loader.hide();
                this.$toast.success('Users has been loaded');
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        }
    }
}
</script>

<style>

</style>