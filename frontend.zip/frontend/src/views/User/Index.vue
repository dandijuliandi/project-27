<template>
    <Navigation></Navigation>
    <div class="container">
        <div class="row">
            <div v-for="user in users" :key="user.id" class="col-md-4 mb-2">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex d-flex align-items-center justify-content-between">
                            <div>
                                {{ user.name }}
                            </div>
                            <div class="btn-group">
                                <button v-on:click="showUser(user.id)" class="btn btn-info btn-sm">
                                    <i class="fas fa-fw fa-info"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { useStorage } from 'vue3-storage';
import { SERVER_API_URL } from './../../utils/constant';
import navigation from './../../components/Navigation.vue';

export default {
    components: {
        Navigation: navigation
    },
    mounted () {
        const storage = useStorage();
        if (!storage.hasKey('user_id')) {
            this.$router.push({
                name: 'user.login'
            });
        } else {
            this.getUsers();
        }
    },
    data () {
        return {
            users: [],
        }
    },
    methods: {
        getUsers: function () {
            let loader = this.$loading.show();
            this.users = [];
            let url = SERVER_API_URL + '/user';
            axios.get(url)
            .then(response => {
                this.users = response.data.data;
                loader.hide();
                this.$toast.success(this.users.length + ' users has been loaded');
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        },
        showUser: function (id) {
            this.$router.push({
                name: 'user.show',
                params: {
                    user: id
                }
            });
        }
    }
}
</script>

<style>

</style>