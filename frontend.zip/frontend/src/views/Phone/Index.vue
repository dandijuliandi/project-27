<template>
    <Navigation></Navigation>
    <div class="container">
        <div class="row mb-3">
            <div class="col-md">
                <router-link class="btn btn-primary" :to="{name: 'phone.create'}">
                    <i class="fas fa-fw fa-plus"></i> Add New Phone
                </router-link>
            </div>
        </div>
        <div class="row">
            <div v-for="phone in phones" :key="phone.id" class="col-md-4 mb-2">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex justify-content-between d-flex align-items-center">
                            <div>
                                {{ phone.number }}
                            </div>
                            <div class="btn-group">
                                <button v-on:click="removePhone(phone.id)" class="btn btn-danger btn-sm">
                                    <i class="fas fa-fw fa-trash"></i>
                                </button>
                                <button v-on:click="editPhone(phone.id)" class="btn btn-success btn-sm">
                                    <i class="fas fa-fw fa-pen"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { useStorage } from 'vue3-storage';
import { SERVER_API_URL } from './../../utils/constant';
import navigation from './../../components/Navigation.vue';

export default {
    components: {
        Navigation: navigation
    },
    mounted () {
        const storage = useStorage();
        if (!storage.hasKey('user_id')) {
            this.$router.push({
                name: 'user.login'
            });
        } else {
            this.getPhones();
        }
    },
    data () {
        return {
            phones: [],
        }
    },
    methods: {
        getPhones: function () {
            let loader = this.$loading.show();
            this.phones = [];
            let url = SERVER_API_URL + '/phone';
            axios.get(url)
            .then(response => {
                this.phones = response.data.data;
                loader.hide();
                this.$toast.success(this.phones.length + ' phones has been loaded');
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        },
        removePhone: function (id) {
            let loader = this.$loading.show();
            let url = SERVER_API_URL + '/phone/destroy/' + id;
            axios.delete(url)
            .then(response => {
                let index = this.phones.findIndex(item => item.id === id);
                this.phones = this.phones.splice(index, 1);
                loader.hide();
                this.$toast.success(response.data.message);
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        },
        editPhone: function (id) {
            this.$router.push({
                name: 'phone.edit',
                params: {
                    phone: id
                }
            });
        }
    }
}
</script>

<style>

</style>