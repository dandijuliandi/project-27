<template>
    <Navigation></Navigation>
    <div class="container">
        <div class="row mb-5">
            <div v-for="(phone, index) in phones" :key="index" class="col-md-4 mb-2">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex d-flex align-items-center justify-content-between">
                            <div>
                                {{ phone }}
                            </div>
                            <div class="btn-group">
                                <router-link :to="{name: 'phone.create', params: {number: encryptNumber('number', phone)}}" class="btn btn-info btn-sm">
                                    <i class="fas fa-fw fa-check"></i>
                                </router-link>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { useStorage } from 'vue3-storage';
import { SERVER_API_URL } from './../../utils/constant';
import navigation from './../../components/Navigation.vue';

export default {
    components: {
        Navigation: navigation
    },
    mounted () {
        const storage = useStorage();
        if (!storage.hasKey('user_id')) {
            this.$router.push({
                name: 'user.login'
            });
        } else {
            this.generateNumbers();
        }
    },
    data () {
        return {
            phones: [],
        }
    },
    methods: {
        generateNumbers: function () {
            let loader = this.$loading.show();
            this.phones = [];
            let url = SERVER_API_URL + '/phone/generate';
            axios.get(url)
            .then(response => {
                this.phones = response.data;
                loader.hide();
                this.$toast.success(this.phones.length + ' phones has been loaded');
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        },
        selectNumber: function (id) {
            this.$router.push({
                name: 'phone.show',
                params: {
                    phone: id
                }
            });
        },
        encryptNumber: function (salt, text) {
            const textToChars = (text) => text.split('').map((c) => c.charCodeAt(0));
            const byteHex = (n) => ('0' + Number(n).toString(16)).substr(-2);
            const applySaltToChar = (code) => textToChars(salt).reduce((a, b) => a ^ b, code);
            return text.split('')
            .map(textToChars)
            .map(applySaltToChar)
            .map(byteHex)
            .join('');
        
        }
    }
}
</script>

<style>

</style>