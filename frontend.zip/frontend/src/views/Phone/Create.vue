<template>
    <Navigation></Navigation>
    <div class="container">
        <div class="row justify-content-center align-middle mt-3">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <b>ADD PHONE NUMBER</b>
                    </div>
                    <div class="card-body">
                        <form v-on:submit.prevent="savePhone()" >
                            <small>Number :</small>
                            <div class="input-group mb-3">
                                <span class="input-group-text"><i class="fas fa-phone fa-fw"></i></span>
                                <input type="text" v-model="form.number" v-on:input="handleNumberInput()" :class="inputClass(error.number.length).text">
                                <div v-if="(error.number.length) > 0" class="invalid-feedback">
                                    <i class="fas fa-exclamation-triangle fa-fw"></i> {{ error.number[0] }}
                                </div>
                            </div>
                            <small>Provider :</small>
                            <div class="input-group mb-3">
                                <label class="input-group-text"><i class="fas fa-wifi fa-fw"></i></label>
                                <select v-model="form.provider_id" :class="inputClass(error.provider_id.length).select">
                                    <option v-for="provider in providers" :key="provider.id" :value="provider.id">{{ provider.name }}</option>
                                </select>
                                <div v-if="(error.provider_id.length) > 0" class="invalid-feedback">
                                    <i class="fas fa-exclamation-triangle fa-fw"></i> {{ error.provider_id[0] }}
                                </div>
                            </div>
                            <div class="input-group btn-group justify-content-end mb-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-fw fa-save"></i> Save
                                </button>
                                <router-link :to="{name: 'phone.generate'}" class="btn btn-success">
                                    <i class="fas fa-question fa-fw"></i> Auto
                                </router-link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import axios from 'axios';
import { SERVER_API_URL } from './../../utils/constant';
import navigation from './../../components/Navigation.vue';

export default {
    mounted () {
        this.error.number = [];
        this.error.provider_id = [];
        this.getProviders();
        if (this.$route.params.number) {
            this.form.number = this.decryptNumber('number', this.$route.params.number);
        }
    },
    components: {
        Navigation: navigation
    },
    data() {
        return {
            form: {
                number: '',
                provider_id: '',
            },
            providers: [],
            error: {
                number: [],
                provider_id: []
            }
        }
    },
    methods: {
        savePhone: function () {
            let loader = this.$loading.show();
            let url = SERVER_API_URL + '/phone/store';
            let body = this.form;
            axios.post(url, body)
            .then(response => {
                this.clearForm();
                this.$toast.success(response.data.message);
                loader.hide();
            })
            .catch(error => {
                let error_data = error.response.data;
                let error_status = error.response.status;
                if (error_status== 422) {
                    let number_error = error_data.errors.number;
                    let provider_id_error = error_data.errors.provider_id;
                    this.error.number = (number_error) ? number_error : [];
                    this.error.provider_id = (provider_id_error) ? provider_id_error : [];
                }
                this.$toast.error(error.message);
                loader.hide();
            });
        },
        getProviders: function () {
            let loader = this.$loading.show();
            this.providers = [];
            let url = SERVER_API_URL + '/provider';
            axios.get(url)
            .then(response => {
                this.providers = response.data.data;
                this.form.provider_id = this.providers[0].id;
                loader.hide();
                this.$toast.success(this.providers.length + ' providers has been loaded');
            })
            .catch(error => {
                loader.hide();
                this.$toast.error(error.message);
            });
        },
        inputClass: function (errorLength) {
            if (errorLength > 0) {
                return {
                    text: 'form-control is-invalid',
                    select: 'form-select is-invalid'
                }
            } else {
                return {
                    text: 'form-control',
                    select: 'form-select'
                }
            }
        },
        clearForm: function () {
            this.form.number = '';
            this.form.provider_id = this.providers[0].id;
            this.error.number = [];
            this.error.provider_id = [];
        },
        handleNumberInput: function () {
            this.form.number = this.form.number.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');
        },
        decryptNumber: function (salt, encoded) {
            const textToChars = (text) => text.split('').map((c) => c.charCodeAt(0));
            const applySaltToChar = (code) => textToChars(salt).reduce((a, b) => a ^ b, code);
            return encoded.match(/.{1,2}/g)
                .map((hex) => parseInt(hex, 16))
                .map(applySaltToChar)
                .map((charCode) => String.fromCharCode(charCode))
                .join('');
        }
    }
}
</script>

<style>

</style>