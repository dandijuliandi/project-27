<template>
<div class="container mt-5 text-center">
    <h3>404 | NOT FOUND</h3>
</div>
</template>

<script>
export default {

}
</script>

<style>

</style>