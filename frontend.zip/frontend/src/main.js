import { createApp } from 'vue';
import App from './App.vue';

import router from './router';

import 'bootstrap/dist/js/bootstrap.min.js';
import 'bootstrap/dist/css/bootstrap.min.css';

import '@fortawesome/fontawesome-free/css/all.min.css';

import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';
const firebaseConfig = {
    apiKey: "AIzaSyAzncMg8TUU-mGQdhe4mEnFxesDpI1JvZM",
    authDomain: "fir-27-68998.firebaseapp.com",
    databaseURL: "https://fir-27-68998-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "fir-27-68998",
    storageBucket: "fir-27-68998.appspot.com",
    messagingSenderId: "125965971197",
    appId: "1:125965971197:web:e7fbce12c319d25b735894",
    measurementId: "G-FQ67GRC0QE"
};
getAnalytics(initializeApp(firebaseConfig));

import VueLoading from 'vue-loading-overlay';
import 'vue-loading-overlay/dist/vue-loading.css';

import Toaster from "@meforma/vue-toaster";

import { Vue3Storage, StorageType } from "vue3-storage";


const app = createApp(App);
app.use(router);
app.use(VueLoading, {
    loader: 'dots'
});
app.use(Toaster, {
    position: 'top-right'
});
app.use(Vue3Storage, { namespace: 'pro_', storage: StorageType.Local });
app.mount('#app');
